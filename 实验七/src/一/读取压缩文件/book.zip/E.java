abstract class AAA {
   abstract protected int getNumber();
} 
class BBB extends AAA {
   public char getNumber(){ return  }
}